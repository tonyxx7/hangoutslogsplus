echo ==[HangoutsLogsPlus Mac]==
echo Opening Log Directories…
echo =============================
echo Find gtp.log and gtpbp.log in the desktop and the compressed log files (gtalkplugin-c*.log.bz2) in the following folders, and attach them to an email to your support representative.
open ~/Library/Application Support/Google/Google Talk Plugin
open ~/Desktop/HangoutsLogs/