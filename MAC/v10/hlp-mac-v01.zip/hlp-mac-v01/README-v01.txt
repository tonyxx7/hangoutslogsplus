==[HangoutsLogs Mac]==
==[Version ==== v0.1]==
Welcome to HangoutsLogs!
To get started, launch Step1.sh!
Used steps from:
https://support.google.com/a/answer/2978955?hl=en
I give all credit for the Google Talk Plugin to Google!
Thanks for using me!