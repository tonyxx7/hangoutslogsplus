echo ==[HangoutsLogPlus Mac]==
echo Welcome back! You can host a hangout and replicate your problem
echo Then E-Mail The Logs by Executing: OpenLogs.sh!
echo Also, Execute DisableHangoutsLog.sh to Disable logging.